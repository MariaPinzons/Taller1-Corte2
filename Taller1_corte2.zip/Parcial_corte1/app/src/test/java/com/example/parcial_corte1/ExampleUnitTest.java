package com.example.parcial_corte1;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);}

    @Test
    public void addition_isCorrectNoPassed() {
        assertEquals(4, 3 + 2);}

    @Test//Prueba de igualdad entre dos cadenas
    public void testStringEquality() {
        String expected = "Hello";
        String actual = "Hello";
        assertEquals(expected, actual);
    }
    @Test//Prueba de igualdad entre dos cadenas
    public void testStringEqualityNoPassed() {
        String expected = "Hello";
        String actual = "Hello World";
        assertEquals(expected, actual);
    }

    @Test//Prueba de un valor booleano verdadero:
    public void testTrueValue() {
        boolean actual = true;
        assertTrue(actual);
    }

    @Test//Prueba de un valor booleano verdadero:
    public void testTrueValueNoPassed() {
        boolean expected = true;
        boolean actual = false;
        assertEquals(expected, actual);
    }

    @Test//Prueba de igualdad entre dos números enteros
    public void testIntegerEquality() {
        int expected = 10;
        int actual = 10;
        assertEquals(expected, actual);
    }

    @Test//Prueba de igualdad entre dos números enteros
    public void testIntegerEqualityNoPassed() {
        int expected = 10;
        int actual = 12;
        assertEquals(expected, actual);
    }

    @Test//Prueba de igualdad entre dos números de punto flotante
    public void testDoubleEquality() {
        double expected = 3.14;
        double actual = 3.14;
        assertEquals(expected, actual, 0.0001);
    }

    @Test
    public void testDoubleEqualityNoPassed() {
        double expected = 3.14;
        double actual = 3.1335;
        assertEquals(expected, actual, 0.0001);
    }

    @Test//Prueba de igualdad entre dos arreglos de enteros
    public void testIntArrayEquality() {
        int[] expected = {1, 2, 3};
        int[] actual = {1, 2, 3};
        assertArrayEquals(expected, actual);
    }

    @Test//Prueba de igualdad entre dos arreglos de enteros
    public void testIntArrayEqualityNoPassed() {
        int[] expected = {1, 2, 3};
        int[] actual = {2, 4, 6};
        assertArrayEquals(expected, actual);
    }

    @Test//Prueba de un número negativo
    public void testNegativeNumber() {
        int actual = -10;
        assertTrue(actual < 0);
    }

    @Test//Prueba de un número negativo
    public void testNegativeNumberNoPassed() {
        int actual = 10;
        assertTrue(actual < 0);
    }

    @Test//Prueba de un número cero
    public void testZeroNumber() {
        int actual = 0;
        assertTrue(actual == 0);
    }

    @Test//Prueba de un número cero
    public void testZeroNumberNoPassed() {
        int actual = 3;
        assertTrue(actual == 0);
    }
}