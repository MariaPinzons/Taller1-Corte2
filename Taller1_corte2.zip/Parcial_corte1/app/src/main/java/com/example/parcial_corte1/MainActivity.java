package com.example.parcial_corte1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.parcial_corte1.DB.DBHelper;
import com.example.parcial_corte1.DB.DbInventario;

public class MainActivity extends AppCompatActivity {

    EditText txtUsuario, txtContraseña;
    Button btnEnviar;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsuario = findViewById(R.id.txtUsuario);
        txtContraseña = findViewById(R.id.txtContraseña);
        btnEnviar = findViewById(R.id.btn_Enviar);


        

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View view) {
                DBHelper dbHelper= new DBHelper(MainActivity.this);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                DbInventario dbInventario = new DbInventario(MainActivity.this);
                Intent intent = new Intent(MainActivity.this, activity3_lista.class);

                if (db != null) {
                    dbInventario.insertarInformacion(txtUsuario.getText().toString(), txtContraseña.getText().toString(), "", "", "");
                    Toast.makeText(MainActivity.this, "Sesión iniciada", Toast.LENGTH_LONG).show();
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Error al iniciar sesión", Toast.LENGTH_LONG).show();
                    }
                }
        });
    }
}