package com.example.parcial_corte1.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parcial_corte1.R;
import com.example.parcial_corte1.entidades.Inventario;

import java.util.ArrayList;

public class ListaInventarioAdapter extends RecyclerView.Adapter<ListaInventarioAdapter.InventarioViewHolder> {

    ArrayList<Inventario> listaInventario;

    public ListaInventarioAdapter(ArrayList<Inventario> listaInventario){
        this.listaInventario = listaInventario;
    }


    @NonNull
    @Override
    public InventarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_activity3_lista,null, false);
        return new InventarioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventarioViewHolder holder, int position) {
        holder.viewNombre.setText(listaInventario.get(position).getNombre());
        holder.viewCantidad.setText(listaInventario.get(position).getCantidad());
        holder.viewPrecio.setText(listaInventario.get(position).getPrecio());

    }

    @Override
    public int getItemCount() {
        return listaInventario.size();
    }

    public class InventarioViewHolder extends RecyclerView.ViewHolder {

        TextView viewNombre, viewCantidad, viewPrecio;

        public InventarioViewHolder(@NonNull View itemView) {
            super(itemView);

            viewNombre = itemView.findViewById(R.id.txtNombreP);
            viewCantidad = itemView.findViewById(R.id.txtCantidadP); //Corregir
            viewPrecio = itemView.findViewById(R.id.txtPrecioP);
        }
    }
}
