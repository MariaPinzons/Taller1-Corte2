package com.example.parcial_corte1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.parcial_corte1.DB.DbInventario;
import com.example.parcial_corte1.adaptadores.ListaInventarioAdapter;
import com.example.parcial_corte1.entidades.Inventario;

import java.util.ArrayList;

public class activity3_lista extends AppCompatActivity {

    RecyclerView listaInventario;
    ArrayList<Inventario> listaArrayInventario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity3_lista);
        listaInventario = findViewById(R.id.listaProductos);
        listaInventario.setLayoutManager(new LinearLayoutManager(this));

        DbInventario dbInventario = new DbInventario(activity3_lista.this);

        listaArrayInventario = new ArrayList<>();
        ListaInventarioAdapter adapter = new ListaInventarioAdapter(dbInventario.mostrarInventario());
        listaInventario.setAdapter(adapter);
    }

    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_principal, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuNuevo:
                nuevoRegistro();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void nuevoRegistro(){
        Intent intent = new Intent( this, Activity2_producto.class);
        startActivity(intent);
    }
}