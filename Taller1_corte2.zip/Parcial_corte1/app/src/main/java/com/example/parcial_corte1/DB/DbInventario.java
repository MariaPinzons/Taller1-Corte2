package com.example.parcial_corte1.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.parcial_corte1.entidades.Inventario;

import java.sql.Array;
import java.util.ArrayList;

public class DbInventario extends DBHelper{
    Context context;

    public DbInventario(@Nullable Context context){
        super(context);
        this.context = context;
    }

    public long insertarInformacion(String usuario, String contraseña, String nombre, String cantidad, String precio) {

        long id = 0;

        try {
            DBHelper dbHelper = new DBHelper(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put("usuario", usuario);
            values.put("contraseña", contraseña);
            values.put("nombre", nombre);
            values.put("cantidad", cantidad);
            values.put("precio", precio);

            id = db.insert(TABLE_INFORMACION, null, values);
        } catch (Exception ex) {
            ex.toString();
        }

        return id;
    }

    public ArrayList<Inventario> mostrarInventario(){
        DBHelper dbHelper = new DBHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ArrayList<Inventario> listaInventario = new ArrayList<>();
        Inventario inventario = null;
        Cursor cursorInventario = null;

        cursorInventario = db.rawQuery("SELECT * FROM " + TABLE_INFORMACION, null);

        if (cursorInventario.moveToFirst()){
            do {
                inventario = new Inventario();
                inventario.setId(cursorInventario.getInt(0));
                inventario.setNombre(cursorInventario.getString(1));
                inventario.setCantidad(cursorInventario.getString(2));
                inventario.setPrecio(cursorInventario.getString(3));
                listaInventario.add(inventario);
            }while (cursorInventario.moveToNext());
        }
        cursorInventario.close();

        return listaInventario;
    }
}
